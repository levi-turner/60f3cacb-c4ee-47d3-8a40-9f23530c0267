// include modules
var express = require('express');
var app = express();
var path = require('path');
var qrsInteract = require('qrs-interact');

var qrsInteractInstance = new qrsInteract("localhost");
var logRoutes = require("./routes/logRoutes.js");

app.use(express.static(path.join(__dirname, 'public')));
app.use("/log/", logRoutes);

// setup server
var server = app.listen(8080);

var isRepoRunning = false;

// Post Notification
setInterval(() => {
    if (!isRepoRunning) {
        qrsInteractInstance.Post(
            'notification?name=ServiceStatus&filter=serviceType eq 3&changeType=2&PropertyName=timestamp',
            "http://localhost:8080/log/notify",
            'json'
        ).then(function(result) {
            if (result.statusCode == 201) {
                isRepoRunning = true;
            }
        });
    } else {
        qrsInteractInstance.Get(
            'about'
        ).then(function(result) {
            if (result.statusCode != 200) {
                isRepoRunning = false;
            }
        });
    }
}, 15000);