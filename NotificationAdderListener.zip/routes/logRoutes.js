var bodyParser = require('body-parser');
var express = require('express');
var fs = require('fs');
var qrsInteract = require('qrs-interact');

var qrsInteractInstance = new qrsInteract("localhost");

var router = express.Router();

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({
    extended: true
}));

var csvFile = "C:\\temp\\serviceStatus.csv";

// Check to see if C:\temp exists
var tempExists = fs.existsSync("C:\\temp");
if (!tempExists) {
    fs.mkdirSync("C:\\temp");
}

var fileExists = fs.existsSync(csvFile);
if (!fileExists) {
    try {
        fs.writeFileSync(csvFile, "notificationTime,hostname,serviceStatusTimestamp,serviceState\n");
    } catch (err) {
        /* Handle the error */
    }
}

router.route('/notify')
    .post(function(request, response, next) {
        response.send('OK');
        next();
    }, function(req, res) {
        console.log(req.body);
        req.body.forEach(serviceStatus => {
            qrsInteractInstance.Get("servicestatus/" + serviceStatus['objectID'])
                .then(function(result) {
                    if (result.statusCode == 200) {
                        var dateNow = new Date();
                        var datetimeString = dateNow.toISOString();
                        var lineToPrint = datetimeString + ',' + result.body['serverNodeConfiguration']['hostName'] + ',' + result.body['timestamp'] + ',' + GetServiceState(result.body['serviceState']) + '\n';
                        try {
                            fs.appendFileSync(csvFile, lineToPrint);
                        } catch (err) {
                            /* Handle the error */
                        }
                    }
                });
        });
    });

function GetServiceState(intValue) {
    switch (intValue) {
        case 0:
            return "Initializing";
            break;
        case 1:
            return "CertificatesNotInstalled";
            break;
        case 2:
            return "Running";
            break;
        case 3:
            return "NoCommunication";
            break;
        case 4:
            return "Disabled";
            break;
        case 5:
            return "Unknown";
            break;
        default:
            return "Invalid Service State";
    }
}

module.exports = router;